// Previous JavaScript plus these additions

// 1. Dark Mode Toggle
const themeToggle = document.querySelector('.theme-toggle');
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    themeToggle.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
});

// 2. Fireworks Effect
function createFirework(x, y) {
    const firework = document.createElement('div');
    firework.className = 'firework';
    firework.style.left = x + 'px';
    firework.style.top = y + 'px';
    document.querySelector('.fireworks-container').appendChild(firework);
    
    setTimeout(() => firework.remove(), 1000);
}

document.querySelector('#home').addEventListener('click', (e) => {
    createFirework(e.clientX, e.clientY);
});

// 3. Mobile Gesture Controls
let touchStartX = 0;
let touchEndX = 0;

document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
    });

    card.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe(card);
    });
});

function handleSwipe(element) {
    const swipeThreshold = 50;
    const diff = touchStartX - touchEndX;

    if (Math.abs(diff) > swipeThreshold) {
        element.classList.toggle('swiped');
    }
}

// 4. Device Orientation Effect
if (window.DeviceOrientationEvent) {
    window.addEventListener('deviceorientation', (event) => {
        const tilt = event.beta; // Forward/backward tilt
        const rotate = event.gamma; // Left/right tilt
        
        document.querySelector('#tiltCard').style.transform = 
            `rotateX(${tilt}deg) rotateY(${rotate}deg)`;
    });
}

// 5. Skill Bars Animation
const observerOptions = {
    threshold: 0.5
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const skillBar = entry.target;
            const percentage = skillBar.getAttribute('data-percentage');
            skillBar.style.width = percentage + '%';
        }
    });
}, observerOptions);

document.querySelectorAll('.skill-bar').forEach(bar => {
    observer.observe(bar);
});

// 6. Typing Animation
function typeWriter(element, text, speed = 100) {
    let i = 0;
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    type();
}

// Initialize typing animation
const titleElement = document.querySelector('.typing-text');
typeWriter(titleElement, 'Welcome to My Portfolio');